<?php
/**
 * NOVA PANEL - API Query Handler
 * Frontend'den gelen sorguları işler ve sonuçları döndürür
 */

header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../config/database.php';
initSession();
requireLogin();

$response = [
    'status' => false,
    'error' => 'Bilinmeyen hata',
    'mesaj' => 'İşlem başarısız'
];

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['status' => false, 'error' => 'Invalid request method'], 405);
}

try {
    // CSRF Token doğrulaması
    $token = $_POST['csrf_token'] ?? '';
    if (!verifyCSRFToken($token)) {
        jsonResponse(['status' => false, 'error' => 'CSRF token hatası'], 403);
    }
    
    $type = $_POST['type'] ?? '';
    $userId = $_SESSION['user_id'];
    $db = getDB();
    
    // Geçerli sorgu türlerini tanımla
    $validTypes = ['tc', 'adsoyad', 'aile', 'sulale', 'es', 'cocuk', 'tcgsm', 'gsmtc'];
    
    if (!in_array($type, $validTypes)) {
        jsonResponse(['status' => false, 'error' => 'Geçersiz sorgu türü'], 400);
    }
    
    // Giriş verilerini topla
    $input = [];
    $requiredFields = [];
    
    switch ($type) {
        case 'tc':
            $requiredFields = ['tc'];
            break;
        case 'adsoyad':
            $requiredFields = ['ad', 'soyad'];
            break;
        case 'aile':
        case 'sulale':
        case 'es':
        case 'cocuk':
            $requiredFields = ['tc'];
            break;
        case 'tcgsm':
            $requiredFields = ['tc'];
            break;
        case 'gsmtc':
            $requiredFields = ['gsm'];
            break;
    }
    
    // Zorunlu alanları kontrol et
    foreach ($requiredFields as $field) {
        $value = trim($_POST[$field] ?? '');
        if (empty($value)) {
            jsonResponse([
                'status' => false,
                'error' => ucfirst($field) . ' boş bırakılamaz',
                'mesaj' => 'Lütfen tüm zorunlu alanları doldurun'
            ], 400);
        }
        $input[$field] = sanitize($value);
    }
    
    // Opsiyonel alanları al
    $optionalFields = ['il', 'ilce'];
    foreach ($optionalFields as $field) {
        if (isset($_POST[$field])) {
            $value = trim($_POST[$field] ?? '');
            if (!empty($value)) {
                $input[$field] = sanitize($value);
            }
        }
    }
    
    // Query log kaydını oluştur
    $inputStr = json_encode($input);
    $ip = getClientIP();
    
    // API'ye sorguyu gönder (mock implementation)
    $result = performQuery($type, $input);
    
    // Sorgu sonucunu log'la
    $stmt = $db->prepare("
        INSERT INTO query_logs(user_id, query_type, query_input, result_status, ip_address)
        VALUES(:uid, :qtype, :qinput, :status, :ip)
    ");
    
    $stmt->execute([
        ':uid' => $userId,
        ':qtype' => $type,
        ':qinput' => $inputStr,
        ':status' => $result['status'] ? 'success' : 'failed',
        ':ip' => $ip
    ]);
    
    // Sorgu sayısını güncelle
    $db->prepare("UPDATE users SET total_queries = total_queries + 1 WHERE id = :id")
        ->execute([':id' => $userId]);
    
    // Cevap gönder
    jsonResponse([
        'status' => $result['status'],
        'sonuc' => $result['data'] ?? null,
        'mesaj' => $result['message'] ?? 'İşlem tamamlandı',
        'error' => $result['error'] ?? null,
        'format' => $result['format'] ?? 'single'
    ]);
    
} catch (Exception $e) {
    logActivity($_SESSION['user_id'], 'query_error', $e->getMessage());
    jsonResponse([
        'status' => false,
        'error' => 'Sorgu işleminde hata oluştu',
        'mesaj' => 'Lütfen daha sonra tekrar deneyin'
    ], 500);
}

/**
 * API'ye sorgu gönder ve sonuç al
 */
function performQuery($type, $input) {
    // Mock veri seti
    $mockData = [
        'tc' => [
            'Ad' => 'Ahmet',
            'Soyad' => 'Yılmaz',
            'TC' => $input['tc'] ?? '—',
            'Doğum Tarihi' => '15.06.1985',
            'Doğum Yeri' => 'İstanbul',
            'Cinsiyet' => 'Erkek',
            'Uyruk' => 'Türk Cumhuriyeti',
            'Medeni Hali' => 'Evli'
        ],
        'adsoyad' => [
            'Ad' => $input['ad'] ?? '—',
            'Soyad' => $input['soyad'] ?? '—',
            'TC' => '12345678901',
            'Doğum Tarihi' => '10.03.1990',
            'Şehir' => $input['il'] ?? 'İstanbul',
            'İlçe' => $input['ilce'] ?? 'Beşiktaş'
        ],
        'aile' => [
            [
                'Ad' => 'Ahmet',
                'Soyad' => 'Yılmaz',
                'TC' => '12345678901',
                'Bağlantı' => 'Eş',
                'Cinsiyet' => 'Erkek'
            ],
            [
                'Ad' => 'Ayşe',
                'Soyad' => 'Yılmaz',
                'TC' => '12345678902',
                'Bağlantı' => 'Eş',
                'Cinsiyet' => 'Kadın'
            ]
        ],
        'sulale' => [
            [
                'Adı' => 'Ahmet',
                'Soyadı' => 'Yılmaz',
                'Nesil' => 'Kendisi',
                'Bağlantı' => 'Birey'
            ],
            [
                'Adı' => 'Mehmet',
                'Soyadı' => 'Yılmaz',
                'Nesil' => 'Baba',
                'Bağlantı' => 'Baba'
            ]
        ],
        'tcgsm' => [
            'TC' => $input['tc'] ?? '—',
            'GSM' => '+90 505 123 45 67',
            'Operatör' => 'Vodafone',
            'Konum' => 'İstanbul'
        ],
        'gsmtc' => [
            'GSM' => $input['gsm'] ?? '—',
            'TC' => '12345678901',
            'Ad Soyad' => 'Ahmet Yılmaz',
            'Operatör' => 'Turkcell'
        ]
    ];
    
    // Geçerli tür kontrolü
    if (!isset($mockData[$type])) {
        return [
            'status' => false,
            'error' => 'Geçersiz sorgu türü',
            'message' => 'Bu sorgu türü desteklenmiyor'
        ];
    }
    
    // Mock cevap döndür
    $data = $mockData[$type];
    
    return [
        'status' => true,
        'data' => $data,
        'message' => 'Sorgu başarıyla tamamlandı',
        'format' => is_array($data) && isset($data[0]) ? 'table' : 'single'
    ];
}
