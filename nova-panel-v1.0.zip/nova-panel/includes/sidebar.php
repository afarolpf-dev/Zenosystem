<?php
// NOVA PANEL - Sidebar Navigation
// includes/sidebar.php
?>
<div id="sidebar" class="sidebar">
    <div class="sidebar-header">
        <h2>NOVA<span>PANEL</span></h2>
        <button class="sidebar-close" onclick="toggleSidebar()">✕</button>
    </div>
    
    <div class="sidebar-menu">
        <div class="menu-section">
            <div class="menu-label">Sorgu Türleri</div>
            <a href="/query.php?type=tc" class="menu-item">🆔 TC Sorgu</a>
            <a href="/query.php?type=adsoyad" class="menu-item">👤 Ad Soyad</a>
            <a href="/query.php?type=aile" class="menu-item">👨‍👩‍👧‍👦 Aile</a>
            <a href="/query.php?type=sulale" class="menu-item">🌳 Şecere</a>
            <a href="/query.php?type=es" class="menu-item">💑 Eş</a>
            <a href="/query.php?type=cocuk" class="menu-item">👶 Çocuk</a>
            <a href="/query.php?type=tcgsm" class="menu-item">📱 TC→GSM</a>
            <a href="/query.php?type=gsmtc" class="menu-item">📞 GSM→TC</a>
        </div>
        
        <div class="menu-section">
            <div class="menu-label">Kontrol Paneli</div>
            <a href="/dashboard.php" class="menu-item">📊 Dashboard</a>
            <a href="#" class="menu-item">⚙️ Ayarlar</a>
            <a href="#" class="menu-item">📋 Tarihçe</a>
        </div>
    </div>
    
    <div class="sidebar-footer">
        <a href="/logout.php" class="sidebar-logout">🚪 Çıkış Yap</a>
    </div>
</div>

<div id="sidebarOverlay" class="sidebar-overlay" onclick="toggleSidebar()"></div>

<style>
.sidebar {
    width: 250px;
    background: rgba(15, 23, 42, 0.95);
    backdrop-filter: blur(10px);
    border-right: 1px solid rgba(148, 163, 184, 0.1);
    height: 100vh;
    position: fixed;
    left: 0;
    top: 0;
    overflow-y: auto;
    z-index: 1000;
    display: flex;
    flex-direction: column;
}

.sidebar-header {
    padding: 20px;
    border-bottom: 1px solid rgba(148, 163, 184, 0.1);
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.sidebar-header h2 {
    font-size: 16px;
    margin: 0;
}

.sidebar-header h2 span {
    color: #3b82f6;
}

.sidebar-close {
    background: none;
    border: none;
    color: #94a3b8;
    font-size: 20px;
    cursor: pointer;
    display: none;
}

.sidebar-menu {
    flex: 1;
    overflow-y: auto;
    padding: 10px 0;
}

.menu-section {
    margin: 15px 0;
}

.menu-label {
    padding: 10px 20px;
    font-size: 11px;
    color: #64748b;
    text-transform: uppercase;
    letter-spacing: 1px;
    font-weight: 600;
}

.menu-item {
    display: block;
    padding: 12px 20px;
    color: #cbd5e1;
    text-decoration: none;
    transition: all 0.3s;
    border-left: 3px solid transparent;
    font-size: 14px;
}

.menu-item:hover {
    background: rgba(59, 130, 246, 0.1);
    color: #3b82f6;
    border-left-color: #3b82f6;
}

.sidebar-footer {
    padding: 20px;
    border-top: 1px solid rgba(148, 163, 184, 0.1);
}

.sidebar-logout {
    display: block;
    padding: 10px 14px;
    background: rgba(239, 68, 68, 0.1);
    border: 1px solid rgba(239, 68, 68, 0.3);
    color: #fca5a5;
    text-decoration: none;
    border-radius: 6px;
    text-align: center;
    transition: all 0.3s;
    font-size: 13px;
    font-weight: 600;
}

.sidebar-logout:hover {
    background: rgba(239, 68, 68, 0.2);
}

.sidebar-overlay {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.5);
    z-index: 999;
}

@media (max-width: 768px) {
    .sidebar {
        transform: translateX(-100%);
        transition: transform 0.3s;
    }
    
    .sidebar.open {
        transform: translateX(0);
    }
    
    .sidebar-close {
        display: block;
    }
    
    .sidebar-overlay.active {
        display: block;
    }
}

/* Scrollbar styling */
.sidebar::-webkit-scrollbar {
    width: 6px;
}

.sidebar::-webkit-scrollbar-track {
    background: transparent;
}

.sidebar::-webkit-scrollbar-thumb {
    background: rgba(148, 163, 184, 0.3);
    border-radius: 3px;
}

.sidebar::-webkit-scrollbar-thumb:hover {
    background: rgba(148, 163, 184, 0.5);
}
</style>

<script>
function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebarOverlay');
    
    if (window.innerWidth <= 768) {
        sidebar.classList.toggle('open');
        overlay.classList.toggle('active');
    } else {
        sidebar.classList.toggle('closed');
    }
}
</script>
