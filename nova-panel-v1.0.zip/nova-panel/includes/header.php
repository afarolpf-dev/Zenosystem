<?php
// NOVA PANEL - Header/Topbar
// includes/header.php
?>
<style>
.topbar {
    position: fixed;
    top: 0;
    left: 250px;
    right: 0;
    height: 60px;
    background: rgba(15, 23, 42, 0.95);
    backdrop-filter: blur(10px);
    border-bottom: 1px solid rgba(148, 163, 184, 0.1);
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0 20px;
    z-index: 100;
    transition: left 0.3s;
}

.topbar.collapsed {
    left: 0;
}

.topbar-left {
    display: flex;
    align-items: center;
    gap: 15px;
}

.topbar-toggle {
    background: none;
    border: none;
    color: #3b82f6;
    font-size: 20px;
    cursor: pointer;
    padding: 8px;
}

.topbar-title {
    font-size: 16px;
    color: #e2e8f0;
    font-weight: 600;
}

.topbar-right {
    display: flex;
    align-items: center;
    gap: 20px;
}

.user-avatar {
    width: 35px;
    height: 35px;
    background: linear-gradient(135deg, #2563eb, #3b82f6);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-weight: 700;
    font-size: 14px;
}

.user-menu {
    position: relative;
}

.user-menu-btn {
    background: none;
    border: none;
    color: #cbd5e1;
    cursor: pointer;
    font-size: 14px;
    transition: color 0.3s;
}

.user-menu-btn:hover {
    color: #3b82f6;
}

.user-dropdown {
    display: none;
    position: absolute;
    top: 100%;
    right: 0;
    background: rgba(30, 41, 59, 0.95);
    border: 1px solid rgba(148, 163, 184, 0.1);
    border-radius: 8px;
    margin-top: 10px;
    min-width: 200px;
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
}

.user-dropdown.active {
    display: block;
}

.dropdown-item {
    display: block;
    padding: 12px 16px;
    color: #cbd5e1;
    text-decoration: none;
    border-bottom: 1px solid rgba(148, 163, 184, 0.1);
    transition: all 0.3s;
    font-size: 13px;
}

.dropdown-item:last-child {
    border-bottom: none;
}

.dropdown-item:hover {
    background: rgba(59, 130, 246, 0.1);
    color: #3b82f6;
}

.main-content {
    margin-left: 250px;
    margin-top: 60px;
    padding: 30px 20px;
    min-height: calc(100vh - 60px);
    transition: margin-left 0.3s;
}

.main-content.full {
    margin-left: 0;
}

@media (max-width: 768px) {
    .topbar {
        left: 0;
    }
    
    .main-content {
        margin-left: 0;
        margin-top: 60px;
    }
}
</style>

<div class="topbar" id="topbar">
    <div class="topbar-left">
        <button class="topbar-toggle" id="sidebarToggle" onclick="toggleSidebar()">☰</button>
        <div class="topbar-title">NOVA PANEL</div>
    </div>
    
    <div class="topbar-right">
        <div class="user-menu">
            <button class="user-menu-btn" onclick="toggleUserMenu()">
                <div class="user-avatar"><?=strtoupper(substr($_SESSION['username'], 0, 1))?></div>
            </button>
            <div class="user-dropdown" id="userDropdown">
                <a href="#" class="dropdown-item">👤 Profil</a>
                <a href="#" class="dropdown-item">⚙️ Ayarlar</a>
                <a href="/logout.php" class="dropdown-item" style="color: #fca5a5;">🚪 Çıkış</a>
            </div>
        </div>
    </div>
</div>

<main class="main-content" id="mainContent">
</main>

<script>
function toggleUserMenu() {
    const dropdown = document.getElementById('userDropdown');
    dropdown.classList.toggle('active');
}

// Dropdown dışına tıklanırsa kapat
document.addEventListener('click', function(event) {
    const userMenu = document.querySelector('.user-menu');
    if (!userMenu.contains(event.target)) {
        document.getElementById('userDropdown').classList.remove('active');
    }
});
</script>
