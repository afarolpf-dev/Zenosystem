<?php
// NOVA PANEL - Database Configuration
// Modern Sorgu Paneli Sistemi v1.0

define('DB_PATH', __DIR__ . '/../db/nova.db');
define('SITE_NAME', 'NOVA PANEL');
define('SITE_VERSION', '1.0');
define('TELEGRAM_CHANNEL', '@novapaneltr');
define('TELEGRAM_BOT_TOKEN', 'YOUR_BOT_TOKEN_HERE');
define('FOUNDER_ID', 0);
define('ADMIN_IDS', '[]');
define('API_BASE_URL', 'http://mockerapi.shop');
define('API_KEY', 'YOUR_API_KEY');
define('MAIL_DOMAIN', '@nova.com');
define('PANEL_URL', 'https://novapanel.site');
define('SESSION_TIMEOUT', 900); // 15 dakika

function initSession() {
    if (session_status() === PHP_SESSION_NONE) {
        ini_set('session.cookie_httponly', 1);
        ini_set('session.cookie_secure', 0);
        ini_set('session.use_strict_mode', 1);
        ini_set('session.cookie_samesite', 'Strict');
        ini_set('session.cookie_lifetime', 0);
        session_start();
    }
    
    if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > SESSION_TIMEOUT)) {
        session_unset();
        session_destroy();
        if (session_status() === PHP_SESSION_NONE) session_start();
        $_SESSION = [];
    }
    $_SESSION['last_activity'] = time();
}

function getDB() {
    static $db = null;
    if ($db === null) {
        $dbDir = dirname(DB_PATH);
        if (!is_dir($dbDir)) mkdir($dbDir, 0700, true);
        $db = new PDO('sqlite:' . DB_PATH);
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        $db->exec('PRAGMA journal_mode=WAL');
        $db->exec('PRAGMA foreign_keys=ON');
    }
    return $db;
}

function generateCSRFToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verifyCSRFToken($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

function sanitize($input) {
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

function jsonResponse($data, $code = 200) {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function requireLogin() {
    if (!isset($_SESSION['user_id'])) {
        header('Location: /index.php');
        exit;
    }
}

function isAdmin() {
    return isset($_SESSION['user_type']) && $_SESSION['user_type'] === 'admin';
}

function getClientIP() {
    if (!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) return $_SERVER['HTTP_CF_CONNECTING_IP'];
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ips = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        return trim($ips[0]);
    }
    return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
}

function logActivity($userId, $activity, $details = '') {
    try {
        $db = getDB();
        $ip = getClientIP();
        $stmt = $db->prepare("
            INSERT INTO activity_logs(user_id, activity, details, ip_address, created_at)
            VALUES(:uid, :act, :det, :ip, datetime('now','localtime'))
        ");
        $stmt->execute([
            ':uid' => $userId,
            ':act' => $activity,
            ':det' => $details,
            ':ip' => $ip
        ]);
    } catch (Exception $e) {
        // Sessiz başarısızlık
    }
}
